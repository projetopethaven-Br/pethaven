# PetHaven — Módulo Jurídico e LGPD

## Arquivos incluídos

- `src/components/Legal/LegalCenter.jsx`
- `src/components/Legal/LegalCenter.css`
- `src/pages/Pesquisa/Pesquisa.jsx` já integrado
- `BACKUP/Codigo_original_enviado.js`

## Instalação passo a passo

1. Feche o servidor local do projeto, caso esteja aberto.
2. Faça uma cópia de segurança da pasta:
   `C:\Projetos\PetHaven\src`
3. Extraia este ZIP.
4. Copie a pasta `src` extraída.
5. Cole dentro de:
   `C:\Projetos\PetHaven`
6. Confirme a mesclagem das pastas e a substituição de `Pesquisa.jsx`.
7. Abra o projeto no VS Code.
8. Execute:
   `npm run dev`
9. Acesse:
   `http://localhost:5173/pesquisa-publica`

## O que testar

- O botão `Política de Privacidade` aparece antes do botão de envio.
- O modal abre e fecha.
- As seis seções jurídicas podem ser navegadas.
- O envio é bloqueado se o consentimento obrigatório não estiver marcado.
- O consentimento para contato é opcional.
- O modal funciona no celular.
- A resposta continua sendo salva normalmente.

## Ajuste obrigatório antes da publicação

Abra:
`src/components/Legal/LegalCenter.jsx`

No início do arquivo, revise:

- `LEGAL_CONTACT_EMAIL`
- `CONTROLLER_NAME`
- `LEGAL_UPDATED_AT`

Não publique dados fictícios. Informe o controlador real e um canal válido para solicitações de privacidade.

## Atenção

Este módulo é uma base técnica e textual. Ele não substitui revisão jurídica profissional. Antes da publicação, a política deverá refletir exatamente o banco de dados, hospedagem, fornecedores, prazos de retenção e medidas de segurança realmente utilizados.

A versão atual da pesquisa ainda usa `localStorage`. Antes da divulgação pública, conecte o formulário a um banco de dados central e atualize a Política de Privacidade para refletir a infraestrutura definitiva.
