import "./Pesquisa.css";
import { useEffect, useMemo, useState } from "react";
import { CheckCircleRounded, ContentCopyRounded, OpenInNewRounded, SendRounded } from "@mui/icons-material";

const initial = {

  estabelecimento:"",

  responsavel:"",

  cidade:"",

  estado:"",

  whatsapp:"",

  email:"",

  tempoMercado:"",

  quantidadePets:"",

  tipo:"",

  ferramentas:[],

  maiorDor:"",

  funcionalidades:[],

  interesse:"",

  beta:""

};
const PUBLIC_URL = `${window.location.origin}/pesquisa-publica`;


export default function Pesquisa({ publicMode = false }) {
  const [form, setForm] = useState(initial);
const [sent, setSent] = useState(false);
const [copied, setCopied] = useState(false);

const [cidades, setCidades] = useState([]);
const [carregandoCidades, setCarregandoCidades] = useState(false);
  const title=useMemo(()=>publicMode?"1º Diagnóstico Nacional da Gestão de Hotéis e Creches Pet":"Pesquisa de Mercado PetHaven",[publicMode]);
  useEffect(() => {

    if (!form.estado) {

        setCidades([]);
        setCarregandoCidades(false);

        return;

    }

    async function carregarMunicipios() {

        try {

            setCarregandoCidades(true);

            const resposta = await fetch(

                `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${form.estado}/municipios?orderBy=nome`

            );

            const dados = await resposta.json();

            setCidades(dados);

        } catch (erro) {

            console.error("Erro ao carregar municípios:", erro);

            setCidades([]);

        } finally {

            setCarregandoCidades(false);

        }

    }

    carregarMunicipios();

}, [form.estado]);
  function change(e){const {name,value}=e.target;setForm(v=>({...v,[name]:value}))}
  function toggle(value){setForm(v=>({...v,ferramentas:v.ferramentas.includes(value)?v.ferramentas.filter(x=>x!==value):[...v.ferramentas,value]}))}
  function submit(e){e.preventDefault();const previous=JSON.parse(localStorage.getItem('pethaven_pesquisa_respostas')||'[]');localStorage.setItem('pethaven_pesquisa_respostas',JSON.stringify([...previous,{...form,enviadoEm:new Date().toISOString()}]));setSent(true);window.scrollTo({top:0,behavior:'smooth'})}
  async function copy(){await navigator.clipboard.writeText(PUBLIC_URL);setCopied(true);setTimeout(()=>setCopied(false),1800)}
  if(sent)return <div className={`research-page ${publicMode?'research-page--public':''}`}><div className="research-success"><CheckCircleRounded/><h1>Resposta recebida. Obrigado!</h1><p>Sua experiência ajudará a definir as prioridades do PetHaven e a construir uma solução realmente útil para hotéis e creches pet.</p><button onClick={()=>{setForm(initial);setSent(false)}}>Enviar outra resposta</button></div></div>;
  return <div className={`research-page ${publicMode?'research-page--public':''}`}>
    <section className="research-hero"><span>Pesquisa nacional • PetHaven</span><h1>{title}</h1><p>Conte como seu estabelecimento trabalha hoje e ajude a construir uma gestão mais simples, segura e eficiente.</p>{!publicMode&&<div className="share-box"><div><strong>Link público do questionário</strong><small>{PUBLIC_URL}</small></div><button onClick={copy}><ContentCopyRounded/>{copied?'Copiado':'Copiar link'}</button><a href={PUBLIC_URL} target="_blank" rel="noreferrer"><OpenInNewRounded/>Abrir</a></div>}</section>
    <form className="research-form" onSubmit={submit}>
      <section className="form-card"><div className="form-card__title"><span>01</span><div><h2>Sobre o estabelecimento</h2><p>Informações básicas para entendermos seu perfil.</p></div></div><div className="form-grid"><label>Nome do estabelecimento<input required name="estabelecimento" value={form.estabelecimento} onChange={change}/></label><label>Nome do responsável<input required name="responsavel" value={form.responsavel} onChange={change}/></label><label>

Estado

<select
    required
    name="estado"
    value={form.estado}
    onChange={change}
>

    <option value="">Selecione...</option>

    <option value="AC">Acre</option>
    <option value="AL">Alagoas</option>
    <option value="AP">Amapá</option>
    <option value="AM">Amazonas</option>
    <option value="BA">Bahia</option>
    <option value="CE">Ceará</option>
    <option value="DF">Distrito Federal</option>
    <option value="ES">Espírito Santo</option>
    <option value="GO">Goiás</option>
    <option value="MA">Maranhão</option>
    <option value="MT">Mato Grosso</option>
    <option value="MS">Mato Grosso do Sul</option>
    <option value="MG">Minas Gerais</option>
    <option value="PA">Pará</option>
    <option value="PB">Paraíba</option>
    <option value="PR">Paraná</option>
    <option value="PE">Pernambuco</option>
    <option value="PI">Piauí</option>
    <option value="RJ">Rio de Janeiro</option>
    <option value="RN">Rio Grande do Norte</option>
    <option value="RS">Rio Grande do Sul</option>
    <option value="RO">Rondônia</option>
    <option value="RR">Roraima</option>
    <option value="SC">Santa Catarina</option>
    <option value="SP">São Paulo</option>
    <option value="SE">Sergipe</option>
    <option value="TO">Tocantins</option>

</select>

</label>

<label>

Cidade

<select
    required
    name="cidade"
    value={form.cidade}
    onChange={change}
    disabled={!form.estado || carregandoCidades}
>

    <option value="">

    {!form.estado
        ? "Selecione primeiro o Estado"
        : carregandoCidades
            ? "Carregando municípios..."
            : "Selecione a cidade"}

</option>

    {cidades.map((cidade) => (

        <option
            key={cidade.id}
            value={cidade.nome}
        >

            {cidade.nome}

        </option>

    ))}

</select>

</label><label>E-mail
<input
type="email"
name="email"
value={form.email}
onChange={change}
/>
</label><label>Tipo de negócio<select required name="tipo" value={form.tipo} onChange={change}><option value="">Selecione</option><option>Hotel pet</option><option>Creche pet</option><option>Hotel + Creche</option><option>Clínica / Pet shop</option><option>Outro</option></select></label></div></section>
      <section className="form-card"><div className="form-card__title"><span>02</span><div><h2>Como funciona hoje</h2><p>Marque todas as ferramentas usadas na operação.</p></div></div><div className="choice-grid">{['WhatsApp','Papel','Planilhas Excel','Google Forms','Sistema próprio','Software de terceiros'].map(x=><button type="button" onClick={()=>toggle(x)} className={form.ferramentas.includes(x)?'choice choice--active':'choice'} key={x}>{form.ferramentas.includes(x)&&<CheckCircleRounded/>}{x}</button>)}</div></section>
      <section className="form-card"><div className="form-card__title"><span>03</span><div><h2>Principal dificuldade</h2><p>Esta resposta é uma das mais importantes da pesquisa.</p></div></div><label>Se pudesse eliminar apenas um problema operacional hoje, qual seria?<textarea required rows="5" name="maiorDor" value={form.maiorDor} onChange={change} placeholder="Ex.: demora no check-in, informações espalhadas no WhatsApp, controle de vacinas..."/></label></section>
      <section className="form-card"><div className="form-card__title"><span>04</span><div><h2>Interesse no PetHaven</h2><p>Queremos entender quem deseja acompanhar os próximos passos.</p></div></div><div className="form-grid"><label>Você teria interesse em uma solução com pré-check-in digital, vacinas, alimentação, medicamentos e histórico?<select required name="interesse" value={form.interesse} onChange={change}><option value="">Selecione</option><option>Sim</option><option>Talvez</option><option>Não</option></select></label><label>Aceitaria testar gratuitamente como parceiro beta?<select required name="beta" value={form.beta} onChange={change}><option value="">Selecione</option><option>Sim</option><option>Talvez</option><option>Não</option></select></label></div></section>
      
      <button className="submit-research" type="submit"><SendRounded/>Enviar participação</button>
    </form>
  </div>
}
