import "./Dashboard.css";

import {
  PetsRounded,
  HotelRounded,
  EventRounded,
  VaccinesRounded,
  TrendingUpRounded,
  WarningAmberRounded,
  RestaurantRounded,
  ChevronRightRounded,
} from "@mui/icons-material";

const agenda = [
  {
    pet: "Bella",
    horario: "08:00",
    servico: "Check-in",
  },
  {
    pet: "Thor",
    horario: "09:30",
    servico: "Banho",
  },
  {
    pet: "Luna",
    horario: "11:00",
    servico: "Hospedagem",
  },
  {
    pet: "Max",
    horario: "14:30",
    servico: "Alta",
  },
];

const pets = [
  {
    nome: "Thor",
    tutor: "Carlos",
    status: "Hospedado",
  },
  {
    nome: "Luna",
    tutor: "Fernanda",
    status: "Banho",
  },
  {
    nome: "Mel",
    tutor: "Roberto",
    status: "Creche",
  },
  {
    nome: "Bella",
    tutor: "Luciana",
    status: "Alta Hoje",
  },
];

export default function Dashboard() {
  return (
    <div className="dashboard-page">

      <div className="dashboard-header">

        <div>

          <h1>Bom dia, Renato 👋</h1>

          <p>
            Bem-vindo ao painel administrativo do PetHaven.
          </p>

        </div>

      </div>

      <section className="kpis">

        <div className="kpi-card">

          <div className="kpi-icon blue">
            <PetsRounded />
          </div>

          <div>

            <small>Pets Hoje</small>

            <h2>38</h2>

            <span>+12%</span>

          </div>

        </div>

        <div className="kpi-card">

          <div className="kpi-icon green">
            <HotelRounded />
          </div>

          <div>

            <small>Hospedagens</small>

            <h2>16</h2>

            <span>92% ocupação</span>

          </div>

        </div>

        <div className="kpi-card">

          <div className="kpi-icon orange">
            <EventRounded />
          </div>

          <div>

            <small>Agenda</small>

            <h2>23</h2>

            <span>Hoje</span>

          </div>

        </div>

        <div className="kpi-card">

          <div className="kpi-icon red">
            <VaccinesRounded />
          </div>

          <div>

            <small>Vacinas</small>

            <h2>4</h2>

            <span>Vencendo</span>

          </div>

        </div>

      </section>

      <section className="dashboard-grid">

        <div className="dashboard-card">

          <div className="card-title">

            <h3>Agenda do Dia</h3>

            <ChevronRightRounded />

          </div>

          {agenda.map((item) => (

            <div
              className="agenda-item"
              key={item.pet}
            >

              <div>

                <strong>{item.pet}</strong>

                <small>{item.servico}</small>

              </div>

              <span>{item.horario}</span>

            </div>

          ))}

        </div>

        <div className="dashboard-card">

          <div className="card-title">

            <h3>Ocupação</h3>

          </div>

          <div className="ocupacao">

            <div className="circle">

              <h2>92%</h2>

            </div>

            <p>

              22 das 24 vagas ocupadas.

            </p>

          </div>

        </div>

        <div className="dashboard-card">

          <div className="card-title">

            <h3>Últimos Pets</h3>

          </div>

          {pets.map((pet) => (

            <div
              className="pet-row"
              key={pet.nome}
            >

              <div className="pet-avatar">

                {pet.nome[0]}

              </div>

              <div>

                <strong>{pet.nome}</strong>

                <small>{pet.tutor}</small>

              </div>

              <span>{pet.status}</span>

            </div>

          ))}

        </div>

        <div className="dashboard-card">

          <div className="card-title">

            <h3>Alertas</h3>

          </div>

          <div className="alert-item">

            <WarningAmberRounded />

            <p>

              4 vacinas vencem esta semana.

            </p>

          </div>

          <div className="alert-item">

            <RestaurantRounded />

            <p>

              7 alimentações programadas às 12h.

            </p>

          </div>

          <div className="alert-item">

            <TrendingUpRounded />

            <p>

              Faturamento +18% este mês.

            </p>

          </div>

        </div>

      </section>

    </div>
  );
}